# Hardsaw PWA — Deployment Guide

## What this is
Hardsaw is a governed construction decision platform.
This package is the standalone PWA that installs on Android (and any phone) — no App Store required.

---

## Deploy to Vercel (5 minutes)

### Option A — Drag and Drop (easiest)
1. Go to https://vercel.com and create a free account
2. From your dashboard, click **"Add New Project"**
3. Click **"drag and drop"** and drag this entire `hardsaw-pwa` folder
4. Vercel auto-detects Vite. Click **Deploy**
5. Your live URL appears in ~60 seconds

### Option B — GitHub (recommended for ongoing updates)
1. Push this folder to a GitHub repo
2. Connect Vercel to GitHub at https://vercel.com
3. Import the repo — Vercel auto-deploys on every push

---

## Install on Android

1. Open Chrome on your Android phone
2. Go to your Vercel URL (e.g. `https://hardsaw-xxx.vercel.app`)
3. Tap the **three-dot menu (⋮)** in Chrome
4. Tap **"Add to Home screen"**
5. Tap **"Add"**
6. Hardsaw is now installed as an app on your phone

It will appear on your home screen with the amber H icon.
It opens fullscreen with no browser chrome — it looks and feels like a native app.

---

## Add your Anthropic API key

The Assist layer (Claude) needs your API key to work.

**Option A — Vercel Environment Variable (recommended)**
1. In Vercel dashboard → your project → Settings → Environment Variables
2. Add: `VITE_ANTHROPIC_KEY` = your key from https://console.anthropic.com
3. Redeploy

**Option B — Local .env file (for dev only)**
Create a file called `.env` in the project root:
```
VITE_ANTHROPIC_KEY=sk-ant-your-key-here
```

> Note: The core deterministic engine (MIRE, estimator, geometry, readiness, BOM, packets, vault)
> runs entirely without an API key. Only the Assist chat layer needs the key.

---

## Local development

```bash
npm install
npm run dev
```

Then open http://localhost:5173

---

## Architecture

```
src/
├── main.jsx      — React entry point
├── App.jsx       — Full mobile-first UI
├── engine.js     — Deterministic truth engine (MIRE, estimator, geometry, readiness, vault)
├── luna.js       — Luna governance kernel (action gate, audit log)
└── assist.js     — Claude AI layer (explain only, bounded by Luna)

public/
├── favicon.svg   — Hardsaw H mark
├── icon-192.png  — Android home screen icon
└── icon-512.png  — Android splash/large icon
```

---

## System doctrine

Luna governs.
Estimator computes.
Assist explains within constraints.
Human is the final authority.

Assist may NOT: mutate rulepacks, invent SKUs, override Luna, change the estimate.
