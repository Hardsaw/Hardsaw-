// ─── HARDSAW CORE ENGINE ─────────────────────────────────────────────────────
// Deterministic truth engine. Pure functions. No drift.
// Rulepack versions are locked. Vendor profiles are locked.
// AI may explain. AI may not estimate.

export const RULEPACKS = {
  chain_link: {
    version: 'CL-v2.1',
    post_spacing_ft: 10,
    terminal_post_dia: 2.375,
    line_post_dia: 1.625,
    top_rail_per_10ft: 1,
    tension_wire_per_100ft: 1,
    tie_wire_per_10ft: 3,
    fabric_overlap_pct: 0.02,
  },
  wood_privacy: {
    version: 'WP-v1.4',
    post_spacing_ft: 8,
    picket_width_in: 5.5,
    picket_gap_in: 0.25,
    rails_per_section: 2,
    post_depth_ratio: 0.33,
  },
  vinyl_pvc: {
    version: 'VP-v1.2',
    post_spacing_ft: 8,
    panel_width_ft: 8,
    rails_per_panel: 2,
  },
  ornamental: {
    version: 'OR-v1.1',
    post_spacing_ft: 6,
    pickets_per_ft: 2,
  },
  farm_ranch: {
    version: 'FR-v1.3',
    post_spacing_ft: 12,
    wire_strands: 5,
    staples_per_post: 6,
  },
}

export const VENDOR_PROFILES = {
  chain_link_galvanized: {
    version: 'AF-GL-v1.0',
    vendor: 'AmeriFence',
    skus: {
      terminal_post_4ft: { sku: 'AF-TP-4-237', unit: 'each', price: 18.5 },
      terminal_post_6ft: { sku: 'AF-TP-6-237', unit: 'each', price: 22.0 },
      line_post_4ft:     { sku: 'AF-LP-4-162', unit: 'each', price: 11.25 },
      line_post_6ft:     { sku: 'AF-LP-6-162', unit: 'each', price: 14.0 },
      top_rail_21ft:     { sku: 'AF-TR-21',    unit: 'each', price: 24.0 },
      fabric_4ft_50ft:   { sku: 'AF-FAB-4-50', unit: 'roll', price: 68.0 },
      fabric_6ft_50ft:   { sku: 'AF-FAB-6-50', unit: 'roll', price: 94.0 },
      tension_wire:      { sku: 'AF-TW-100',   unit: 'roll', price: 12.0 },
      tie_wire:          { sku: 'AF-TIE-250',  unit: 'bag',  price: 8.5 },
      walk_gate_4ft:     { sku: 'AF-WG-4',     unit: 'each', price: 145.0 },
      drive_gate_12ft:   { sku: 'AF-DG-12',    unit: 'each', price: 380.0 },
    },
  },
  chain_link_black: {
    version: 'AF-BK-v1.0',
    vendor: 'AmeriFence',
    skus: {
      terminal_post_4ft: { sku: 'AF-TP-4-BK',     unit: 'each', price: 22.0 },
      terminal_post_6ft: { sku: 'AF-TP-6-BK',     unit: 'each', price: 27.0 },
      line_post_4ft:     { sku: 'AF-LP-4-BK',     unit: 'each', price: 14.0 },
      line_post_6ft:     { sku: 'AF-LP-6-BK',     unit: 'each', price: 17.5 },
      top_rail_21ft:     { sku: 'AF-TR-21-BK',    unit: 'each', price: 29.0 },
      fabric_4ft_50ft:   { sku: 'AF-FAB-4-BK-50', unit: 'roll', price: 88.0 },
      fabric_6ft_50ft:   { sku: 'AF-FAB-6-BK-50', unit: 'roll', price: 118.0 },
      tension_wire:      { sku: 'AF-TW-BK-100',   unit: 'roll', price: 16.0 },
      tie_wire:          { sku: 'AF-TIE-BK-250',  unit: 'bag',  price: 10.5 },
      walk_gate_4ft:     { sku: 'AF-WG-4-BK',     unit: 'each', price: 178.0 },
      drive_gate_12ft:   { sku: 'AF-DG-12-BK',    unit: 'each', price: 445.0 },
    },
  },
  wood_privacy: {
    version: 'GEN-WP-v1.0',
    vendor: 'Generic Lumber',
    skus: {
      post_4x4_8ft:   { sku: 'LUM-POST-4x4-8',   unit: 'each', price: 14.5 },
      picket_1x6_6ft: { sku: 'LUM-PICK-1x6-6',   unit: 'each', price: 3.25 },
      rail_2x4_8ft:   { sku: 'LUM-RAIL-2x4-8',   unit: 'each', price: 5.5 },
      concrete_bag:   { sku: 'CON-60LB',          unit: 'bag',  price: 7.25 },
      screws_lb:      { sku: 'HDW-SCREW-EXT-1LB', unit: 'lb',   price: 9.0 },
      walk_gate_wood: { sku: 'GATE-WD-WLK',       unit: 'each', price: 195.0 },
    },
  },
  generic: {
    version: 'GEN-v1.0',
    vendor: 'Generic',
    skus: {
      post:  { sku: 'GEN-POST',  unit: 'each',    price: 20 },
      panel: { sku: 'GEN-PANEL', unit: 'section', price: 85 },
      gate:  { sku: 'GEN-GATE', unit: 'each',    price: 220 },
    },
  },
}

// Simple deterministic hash
export function simpleHash(str) {
  let h = 0
  for (let i = 0; i < str.length; i++) {
    h = Math.imul(31, h) + str.charCodeAt(i) | 0
  }
  return Math.abs(h).toString(16).padStart(8, '0').toUpperCase()
}

// MIRE — natural language → canonical spec
export function mireRouter(rawInput) {
  const s = rawInput.toLowerCase()
  const spec = {
    raw_input: rawInput,
    trade: 'fence',
    family: null,
    height_ft: 4,
    finish: 'galvanized',
    linear_ft: null,
    gates: 0,
    gate_type: 'walk',
    site_flags: [],
    corners: 2,
    ends: 2,
  }

  // Family
  if (/chain.?link|chainlink/.test(s))              spec.family = 'chain_link'
  else if (/wood|privacy|cedar|pine/.test(s))       spec.family = 'wood_privacy'
  else if (/vinyl|pvc/.test(s))                     spec.family = 'vinyl_pvc'
  else if (/ornamental|iron|aluminum|aluminium/.test(s)) spec.family = 'ornamental'
  else if (/farm|ranch|field fence|wire fence/.test(s))  spec.family = 'farm_ranch'
  else                                               spec.family = 'chain_link'

  // Height
  const hm = s.match(/(\d+)\s*(?:ft|foot|feet|')/)
  if (hm) spec.height_ft = parseInt(hm[1])

  // Linear footage — look for 3+ digit number or explicit ft
  const lm = s.match(/(\d+)\s*(?:linear\s*)?(?:ft|foot|feet|lf)/)
  if (lm) spec.linear_ft = parseInt(lm[1])
  else { const nm = s.match(/(\d{3,})/); if (nm) spec.linear_ft = parseInt(nm[1]) }

  // Finish
  if (/black|blk/.test(s))           spec.finish = 'black'
  else if (/white/.test(s))          spec.finish = 'white'
  else if (/tan|beige/.test(s))      spec.finish = 'tan'
  else                               spec.finish = 'galvanized'

  // Gates
  const gm = s.match(/(one|two|three|four|\d+)\s*gate/)
  if (gm) {
    const map = { one:1, two:2, three:3, four:4 }
    spec.gates = map[gm[1]] || parseInt(gm[1]) || 1
  }
  if (/double gate|drive gate|driveway/.test(s)) spec.gate_type = 'drive'

  // Site flags
  if (/hoa/.test(s))                  spec.site_flags.push('HOA')
  if (/rock/.test(s))                 spec.site_flags.push('rocky_soil')
  if (/flood/.test(s))                spec.site_flags.push('flood_zone')
  if (/permit/.test(s))               spec.site_flags.push('permit_required')
  if (/easement/.test(s))             spec.site_flags.push('easement')
  if (/slope|hill|grade/.test(s))     spec.site_flags.push('graded_terrain')

  return spec
}

// Geometry engine — locked rules
export function geometryEngine(spec) {
  if (!spec.linear_ft) return null
  const rp = RULEPACKS[spec.family]
  const spacing = rp.post_spacing_ft
  const sections = Math.ceil(spec.linear_ft / spacing)
  const line_posts = Math.max(0, sections - 1)
  const terminal_posts = spec.corners * 2 + spec.ends + spec.gates * 2
  const geo_hash = simpleHash(`${spec.family}|${spec.linear_ft}|${spec.height_ft}|${spacing}|${sections}`)
  return { linear_ft: spec.linear_ft, sections, line_posts, terminal_posts, post_spacing_ft: spacing, geometry_hash: geo_hash }
}

// Deterministic estimator — pure function
export function runEstimator(spec, geo) {
  if (!geo) return null
  const rp = RULEPACKS[spec.family]
  const warnings = []
  const bom = []

  let vk = spec.family === 'chain_link'
    ? (spec.finish === 'black' ? 'chain_link_black' : 'chain_link_galvanized')
    : spec.family === 'wood_privacy' ? 'wood_privacy' : 'generic'
  const vendor = VENDOR_PROFILES[vk]

  if (spec.family === 'chain_link') {
    const v = vendor.skus
    const tpKey = spec.height_ft <= 4 ? 'terminal_post_4ft' : 'terminal_post_6ft'
    const lpKey = spec.height_ft <= 4 ? 'line_post_4ft' : 'line_post_6ft'
    const fabKey = spec.height_ft <= 4 ? 'fabric_4ft_50ft' : 'fabric_6ft_50ft'
    const fabRolls = Math.ceil((spec.linear_ft * 1.02) / 50)
    const railQty   = Math.ceil(spec.linear_ft / 21) + 1
    const twRolls   = Math.ceil(spec.linear_ft / 100) + 1
    const tieBags   = Math.ceil(spec.linear_ft / 10 * rp.tie_wire_per_10ft / 50) + 1
    bom.push({ ...v[tpKey],  qty: geo.terminal_posts, line: 'Terminal Posts' })
    bom.push({ ...v[lpKey],  qty: geo.line_posts,     line: 'Line Posts' })
    bom.push({ ...v.top_rail_21ft, qty: railQty,      line: 'Top Rail (21ft)' })
    bom.push({ ...v[fabKey], qty: fabRolls,           line: 'Chain Link Fabric' })
    bom.push({ ...v.tension_wire, qty: twRolls,       line: 'Tension Wire' })
    bom.push({ ...v.tie_wire,     qty: tieBags,       line: 'Tie Wire' })
    if (spec.gates > 0) {
      const gk = spec.gate_type === 'drive' ? 'drive_gate_12ft' : 'walk_gate_4ft'
      bom.push({ ...v[gk], qty: spec.gates, line: spec.gate_type === 'drive' ? 'Drive Gate (12ft)' : 'Walk Gate (4ft)' })
    }
  } else if (spec.family === 'wood_privacy') {
    const v = vendor.skus
    const pickets_per_ft = 12 / (rp.picket_width_in + rp.picket_gap_in)
    const picketQty = Math.ceil(spec.linear_ft * pickets_per_ft * 1.05)
    const postQty   = geo.terminal_posts + geo.line_posts
    const railQty   = Math.ceil(spec.linear_ft / 8) * rp.rails_per_section
    bom.push({ ...v.post_4x4_8ft,   qty: postQty,            line: '4×4 Posts' })
    bom.push({ ...v.picket_1x6_6ft, qty: picketQty,          line: 'Pickets (1×6)' })
    bom.push({ ...v.rail_2x4_8ft,   qty: railQty,            line: 'Rails (2×4)' })
    bom.push({ ...v.concrete_bag,   qty: postQty * 2,        line: 'Concrete (60lb)' })
    bom.push({ ...v.screws_lb,      qty: Math.ceil(picketQty/100), line: 'Exterior Screws' })
    if (spec.gates > 0) bom.push({ ...v.walk_gate_wood, qty: spec.gates, line: 'Walk Gate (Wood)' })
  } else {
    const v = vendor.skus
    bom.push({ ...v.post,  qty: geo.terminal_posts + geo.line_posts, line: 'Posts (Generic)' })
    bom.push({ ...v.panel, qty: geo.sections,                        line: 'Panels/Sections' })
    if (spec.gates > 0) bom.push({ ...v.gate, qty: spec.gates, line: 'Gates (Generic)' })
    warnings.push('Generic profile — vendor SKUs not yet mapped for this family')
  }

  if (spec.height_ft > 8)            warnings.push('Height >8ft may require permit')
  if (spec.linear_ft > 1000)         warnings.push('Large job — verify phased delivery')
  if (spec.site_flags.includes('rocky_soil'))      warnings.push('Rocky soil — auger rental likely')
  if (spec.site_flags.includes('HOA'))             warnings.push('HOA job — confirm approved material before ordering')
  if (spec.site_flags.includes('flood_zone'))      warnings.push('Flood zone — check local code for post depth')
  if (spec.site_flags.includes('graded_terrain'))  warnings.push('Graded terrain — stepped or racked install required')

  const totalMaterial = Math.round(bom.reduce((s, i) => s + i.qty * i.price, 0) * 100) / 100
  const laborEstimate = Math.round(spec.linear_ft * (spec.family === 'chain_link' ? 12 : 18))
  const output_hash   = simpleHash(JSON.stringify({ spec, geo, bom }))

  return {
    bom, warnings, totalMaterial, laborEstimate,
    rulepack_version: rp.version,
    vendor_version: vendor.version,
    vendor_name: vendor.vendor,
    output_hash,
    geometry_hash: geo.geometry_hash,
  }
}

// Readiness engine
export function readinessEngine(spec, geo, result) {
  const blockers = []
  const warnings = [...(result?.warnings || [])]
  if (!spec.linear_ft)                              blockers.push('Linear footage not provided')
  if (!spec.family)                                 blockers.push('Material family not identified')
  if (spec.height_ft < 2 || spec.height_ft > 12)   blockers.push('Height out of range (2–12ft)')
  if (spec.site_flags.includes('permit_required'))  blockers.push('Permit required — obtain before scheduling crew')
  if (spec.site_flags.includes('easement'))         blockers.push('Easement flagged — verify property lines first')
  if (spec.site_flags.includes('HOA'))              warnings.push('HOA approval confirmation required before ordering')
  const status = blockers.length > 0 ? 'not_ready' : warnings.length > 0 ? 'needs_review' : 'ready'
  return { status, blockers, warnings }
}

// LifeVault — append-only tamper-evident chain
export class LifeVault {
  constructor() { this.chain = [] }
  append(eventType, data) {
    const prev  = this.chain.length > 0 ? this.chain[this.chain.length - 1].hash : 'GENESIS'
    const hash  = simpleHash(JSON.stringify({ eventType, data, prev, ts: Date.now() }))
    const entry = { eventType, hash, prev: prev.slice(0,8), ts: new Date().toISOString() }
    this.chain.push(entry)
    return hash
  }
  getChain() { return [...this.chain] }
}
