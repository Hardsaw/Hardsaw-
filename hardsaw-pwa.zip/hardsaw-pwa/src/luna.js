// ─── LUNA GOVERNANCE KERNEL ───────────────────────────────────────────────────
// Luna governs. Assist orchestrates within constraints.
// Children cannot raise their own authority.
// Forbidden actions are blocked permanently.

const ALLOWED_ACTIONS = new Set([
  'normalize_spec',
  'run_estimator',
  'check_readiness',
  'generate_packets',
  'vault_append',
  'assist_chat',
  'clif_capture',
  'proof_emit',
])

const FORBIDDEN_ACTIONS = new Set([
  'mutate_rulepack',
  'invent_sku',
  'override_luna',
  'bypass_gate',
  'promote_to_golden_vector',
  'modify_vendor_profile',
])

export class LunaKernel {
  constructor(onLog) {
    this.log = []
    this.frozen = false
    this.onLog = onLog || (() => {})
  }

  gate(action, payload = {}) {
    if (this.frozen) {
      const entry = { ts: new Date().toISOString(), action, result: 'BLOCKED', reason: 'System frozen' }
      this.log.push(entry); this.onLog(entry)
      return false
    }
    if (FORBIDDEN_ACTIONS.has(action)) {
      const entry = { ts: new Date().toISOString(), action, result: 'BLOCKED', reason: 'Forbidden action' }
      this.log.push(entry); this.onLog(entry)
      return false
    }
    if (!ALLOWED_ACTIONS.has(action)) {
      const entry = { ts: new Date().toISOString(), action, result: 'BLOCKED', reason: 'Not in allowlist' }
      this.log.push(entry); this.onLog(entry)
      return false
    }
    const entry = { ts: new Date().toISOString(), action, result: 'ALLOWED' }
    this.log.push(entry); this.onLog(entry)
    return true
  }

  freeze() { this.frozen = true }
  unfreeze() { this.frozen = false }
  getLog() { return [...this.log] }
}
