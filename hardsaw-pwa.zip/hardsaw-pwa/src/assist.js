// ─── ASSIST LAYER — Claude API ────────────────────────────────────────────────
// Assist may: explain, summarize, clarify, guide.
// Assist may not: estimate, mutate, invent SKUs, override Luna.

const ASSIST_SYSTEM = `You are Assist — the structured operator layer of Hardsaw, 
a governed construction decision platform. Luna governance has already approved this job.

Your role:
- Explain outputs clearly in contractor-grade language
- Surface warnings and blockers prominently  
- Answer questions about the job, BOM, packets, or readiness
- Help the contractor understand what the estimate means

Hard rules you must never break:
- You are NOT the estimator. The deterministic engine already ran. You explain what it found.
- Never invent quantities or prices
- Never suggest changing a SKU
- Never override a readiness decision
- Never claim a blocked job is ready
- Keep responses short and direct. Contractors don't want essays.`

export async function assistSummary(spec, geo, result, readiness) {
  const prompt = `Job received: "${spec.raw_input}"

Normalized spec:
- Family: ${spec.family} | Height: ${spec.height_ft}ft | Linear: ${spec.linear_ft || 'NOT PROVIDED'}ft
- Finish: ${spec.finish} | Gates: ${spec.gates} (${spec.gate_type}) | Flags: ${spec.site_flags.join(', ') || 'none'}

Engine output:
- Readiness: ${readiness.status.toUpperCase()}
- Blockers: ${readiness.blockers.join('; ') || 'none'}
- Warnings: ${readiness.warnings.join('; ') || 'none'}
- Material total: $${result?.totalMaterial?.toLocaleString() || 'N/A'}
- Labor estimate: $${result?.laborEstimate?.toLocaleString() || 'N/A'}
- Output hash: ${result?.output_hash || 'N/A'}

Give a 2-3 sentence contractor-grade summary. Lead with the most important thing.`

  return callAssist(prompt)
}

export async function assistChat(message, jobContext) {
  const ctx = jobContext
    ? `Current job context:
- Family: ${jobContext.spec?.family} | Height: ${jobContext.spec?.height_ft}ft | Linear: ${jobContext.spec?.linear_ft}ft
- Finish: ${jobContext.spec?.finish} | Gates: ${jobContext.spec?.gates}
- Readiness: ${jobContext.readiness?.status}
- Material: $${jobContext.result?.totalMaterial?.toLocaleString()} | Labor: $${jobContext.result?.laborEstimate?.toLocaleString()}
- Blockers: ${jobContext.readiness?.blockers?.join('; ') || 'none'}
- Warnings: ${jobContext.readiness?.warnings?.join('; ') || 'none'}`
    : 'No job loaded yet.'

  return callAssist(`${ctx}\n\nContractor question: ${message}`)
}

async function callAssist(userMessage) {
  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: ASSIST_SYSTEM,
        messages: [{ role: 'user', content: userMessage }],
      }),
    })
    const data = await res.json()
    return data.content?.[0]?.text || 'Assist unavailable.'
  } catch {
    return 'Assist offline — engine results above are still valid.'
  }
}
