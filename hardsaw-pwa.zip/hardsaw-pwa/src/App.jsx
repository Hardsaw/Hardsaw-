import { useState, useRef, useEffect, useCallback } from 'react'
import { mireRouter, geometryEngine, runEstimator, readinessEngine, LifeVault } from './engine.js'
import { LunaKernel } from './luna.js'
import { assistSummary, assistChat } from './assist.js'

// ─── CONSTANTS ────────────────────────────────────────────────────────────────
const STATUS = {
  ready:       { color: '#00FF88', label: 'READY TO EXECUTE' },
  needs_review:{ color: '#FFB800', label: 'NEEDS REVIEW' },
  not_ready:   { color: '#FF3B3B', label: 'NOT READY' },
}

const TABS = ['BOM', 'READY', 'PACKETS', 'VAULT']

// ─── STYLES ───────────────────────────────────────────────────────────────────
const C = {
  bg:     '#0A0A0A',
  panel:  '#111111',
  border: '#222222',
  dim:    '#333333',
  muted:  '#555555',
  text:   '#E8E0D0',
  amber:  '#FFB800',
  green:  '#00FF88',
  red:    '#FF3B3B',
  mono:   "'Courier New', 'Lucida Console', monospace",
}

const s = {
  root: {
    minHeight: '100dvh',
    background: C.bg,
    color: C.text,
    fontFamily: C.mono,
    display: 'flex',
    flexDirection: 'column',
    overflowX: 'hidden',
  },
  // Header
  header: {
    background: C.panel,
    borderBottom: `2px solid ${C.dim}`,
    padding: '12px 16px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    position: 'sticky',
    top: 0,
    zIndex: 100,
    flexShrink: 0,
  },
  logo: { fontSize: 20, fontWeight: 'bold', letterSpacing: 4, color: C.amber },
  logoSub: { fontSize: 8, color: C.muted, letterSpacing: 2, marginTop: 2 },
  lunaChip: {
    display: 'flex', alignItems: 'center', gap: 5,
    fontSize: 9, color: C.muted, letterSpacing: 1,
  },
  dot: { width: 6, height: 6, borderRadius: '50%', background: C.green, flexShrink: 0 },
  // Scroll body
  body: { flex: 1, padding: '16px', overflowY: 'auto', WebkitOverflowScrolling: 'touch' },
  // Intake
  hint: {
    background: '#0D0D0D', border: `1px solid ${C.dim}`, borderRadius: 2,
    padding: '12px 14px', marginBottom: 14, fontSize: 11, color: C.muted, lineHeight: 1.7,
  },
  hintEx: { color: C.dim, marginTop: 6, lineHeight: 1.8 },
  label: { fontSize: 9, letterSpacing: 3, color: C.muted, marginBottom: 6, display: 'block' },
  textarea: {
    width: '100%', background: C.panel, border: `1px solid ${C.dim}`,
    color: C.text, fontFamily: C.mono, fontSize: 15, padding: '12px',
    resize: 'none', outline: 'none', borderRadius: 2, lineHeight: 1.5,
    boxSizing: 'border-box',
  },
  runBtn: {
    width: '100%', background: C.amber, color: C.bg, border: 'none',
    padding: '14px', fontSize: 11, letterSpacing: 3, fontWeight: 'bold',
    cursor: 'pointer', fontFamily: C.mono, marginTop: 8, borderRadius: 2,
    WebkitTapHighlightColor: 'transparent',
  },
  // Thinking
  thinking: { textAlign: 'center', padding: '60px 20px', color: C.muted, fontSize: 11, letterSpacing: 3 },
  thinkingIcon: { fontSize: 28, marginBottom: 14, display: 'block' },
  // Status bar
  statusBar: (status) => ({
    background: C.panel, border: `1px solid ${STATUS[status].color}`,
    padding: '12px 14px', display: 'flex', justifyContent: 'space-between',
    alignItems: 'center', marginBottom: 14, borderRadius: 2,
  }),
  statusLabel: (status) => ({ color: STATUS[status].color, fontSize: 10, letterSpacing: 2, fontWeight: 'bold' }),
  statusSub: { fontSize: 9, color: C.muted, marginTop: 2 },
  statusHash: { fontSize: 10, color: C.dim },
  // Card
  card: { background: C.panel, border: `1px solid ${C.border}`, padding: '14px', marginBottom: 12, borderRadius: 2 },
  cardTitle: { fontSize: 8, letterSpacing: 3, color: C.muted, marginBottom: 10, borderBottom: `1px solid ${C.border}`, paddingBottom: 7 },
  // Spec grid
  specGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 },
  specKey: { fontSize: 9, color: C.muted, letterSpacing: 1 },
  specVal: { fontSize: 13, color: C.text, fontWeight: 'bold', marginTop: 1 },
  flags: { marginTop: 10, fontSize: 9, color: C.amber, letterSpacing: 1 },
  // Tabs
  tabs: { display: 'flex', gap: 2, marginBottom: 10 },
  tab: (a) => ({
    flex: 1, padding: '10px 2px', background: a ? C.amber : C.panel,
    color: a ? C.bg : C.muted, border: `1px solid ${a ? C.amber : C.border}`,
    fontSize: 9, letterSpacing: 2, cursor: 'pointer', fontFamily: C.mono,
    fontWeight: a ? 'bold' : 'normal', borderRadius: 2,
    WebkitTapHighlightColor: 'transparent',
  }),
  // BOM
  bomHead: { display: 'grid', gridTemplateColumns: '1fr 36px 60px 64px', gap: 4, padding: '4px 0 8px', borderBottom: `1px solid ${C.dim}`, fontSize: 8, color: C.muted, letterSpacing: 1 },
  bomRow: { display: 'grid', gridTemplateColumns: '1fr 36px 60px 64px', gap: 4, padding: '7px 0', borderBottom: `1px solid #161616`, fontSize: 11, alignItems: 'center' },
  bomSku: { fontSize: 8, color: C.dim, marginTop: 2 },
  totalRow: { display: 'flex', justifyContent: 'space-between', padding: '10px 0 0', borderTop: `1px solid ${C.dim}`, fontSize: 13 },
  hashLine: { fontSize: 8, color: '#2A2A2A', marginTop: 6, wordBreak: 'break-all', letterSpacing: 0.5 },
  // Readiness
  readyStatus: (status) => ({ color: STATUS[status].color, fontSize: 14, fontWeight: 'bold', marginBottom: 12 }),
  alertList: { listStyle: 'none', padding: 0, margin: '0 0 12px' },
  alertItem: (type) => ({ padding: '7px 0', borderBottom: `1px solid #161616`, fontSize: 12, color: type === 'blocker' ? C.red : C.amber }),
  // Packets
  packetSection: { marginBottom: 14 },
  packetHead: { fontSize: 8, letterSpacing: 2, color: C.muted, marginBottom: 7, paddingBottom: 5, borderBottom: `1px solid ${C.border}` },
  packetBody: { fontSize: 11, lineHeight: 1.9, color: '#999' },
  // Vault
  vaultRow: { display: 'flex', gap: 10, padding: '5px 0', borderBottom: `1px solid #161616`, fontSize: 9, alignItems: 'center' },
  vaultEvent: { color: C.amber, minWidth: 140, fontSize: 9 },
  vaultHash: { color: C.dim, fontFamily: C.mono },
  // Chat
  chatWrap: { background: '#0D0D0D', border: `1px solid ${C.border}`, borderRadius: 2, marginBottom: 12 },
  chatHead: { padding: '9px 13px', borderBottom: `1px solid ${C.border}`, fontSize: 8, letterSpacing: 3, color: C.muted, display: 'flex', justifyContent: 'space-between' },
  chatBody: { padding: '12px', minHeight: 70, maxHeight: 240, overflowY: 'auto', WebkitOverflowScrolling: 'touch' },
  chatMsg: (role) => ({ marginBottom: 12, fontSize: 13, lineHeight: 1.6, color: role === 'assist' ? C.text : '#777', borderLeft: `2px solid ${role === 'assist' ? C.amber : C.dim}`, paddingLeft: 10 }),
  chatRole: (role) => ({ fontSize: 8, letterSpacing: 2, color: role === 'assist' ? C.amber : '#444', marginBottom: 3 }),
  chatInputRow: { display: 'flex', borderTop: `1px solid ${C.border}` },
  chatInput: { flex: 1, background: 'transparent', border: 'none', color: C.text, fontFamily: C.mono, fontSize: 13, padding: '11px 13px', outline: 'none' },
  chatSend: { background: 'transparent', border: 'none', borderLeft: `1px solid ${C.border}`, color: C.amber, fontSize: 20, padding: '0 15px', cursor: 'pointer' },
  // Luna log
  lunaRow: { display: 'flex', gap: 12, padding: '5px 0', borderBottom: `1px solid #161616`, fontSize: 9 },
  newJobBtn: { background: 'transparent', border: `1px solid ${C.dim}`, color: C.muted, padding: '10px 14px', fontSize: 9, letterSpacing: 2, cursor: 'pointer', fontFamily: C.mono, width: '100%', marginBottom: 14, borderRadius: 2 },
}

// ─── APP ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [input, setInput]       = useState('')
  const [stage, setStage]       = useState('idle')  // idle | thinking | result
  const [job, setJob]           = useState(null)
  const [tab, setTab]           = useState('BOM')
  const [lunaLog, setLunaLog]   = useState([])
  const [chat, setChat]         = useState([])
  const [chatInput, setChatInput] = useState('')
  const [chatLoading, setChatLoading] = useState(false)
  const chatEndRef = useRef(null)
  const lunaRef    = useRef(null)
  const vaultRef   = useRef(null)

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [chat])

  const addLog = useCallback((entry) => setLunaLog(l => [...l, entry]), [])

  async function runJob() {
    if (!input.trim()) return
    setStage('thinking')
    setJob(null); setLunaLog([]); setChat([])

    const luna  = new LunaKernel(addLog)
    const vault = new LifeVault()
    lunaRef.current  = luna
    vaultRef.current = vault

    await new Promise(r => setTimeout(r, 400))

    luna.gate('normalize_spec')
    const spec = mireRouter(input)
    vault.append('INTENT_CAPTURED', { raw: input })
    vault.append('SPEC_NORMALIZED', { family: spec.family, height: spec.height_ft, linear_ft: spec.linear_ft })

    luna.gate('run_estimator')
    const geo    = geometryEngine(spec)
    const result = runEstimator(spec, geo)
    if (result) vault.append('ESTIMATE_PRODUCED', { output_hash: result.output_hash, total: result.totalMaterial })

    luna.gate('check_readiness')
    const readiness = readinessEngine(spec, geo, result)
    vault.append('READINESS_CHECKED', { status: readiness.status })

    luna.gate('generate_packets')
    vault.append('PACKETS_GENERATED', { job_id: result?.output_hash })

    setJob({ spec, geo, result, readiness, vaultChain: vault.getChain() })
    setStage('result')

    // Assist summary async
    luna.gate('assist_chat')
    const summary = await assistSummary(spec, geo, result, readiness)
    setChat([{ role: 'assist', text: summary }])
  }

  async function sendChat() {
    if (!chatInput.trim() || chatLoading) return
    const msg = chatInput.trim()
    setChatInput('')
    setChatLoading(true)
    setChat(h => [...h, { role: 'user', text: msg }])
    lunaRef.current?.gate('assist_chat')
    const reply = await assistChat(msg, job)
    setChat(h => [...h, { role: 'assist', text: reply }])
    setChatLoading(false)
  }

  function reset() {
    setStage('idle'); setInput(''); setJob(null)
    setLunaLog([]); setChat([]); setTab('BOM')
  }

  // ── RENDER ──────────────────────────────────────────────────────────────────
  return (
    <div style={s.root}>
      {/* Header */}
      <div style={s.header}>
        <div>
          <div style={s.logo}>HARDSAW</div>
          <div style={s.logoSub}>GOVERNED BY LUNA · v1.0</div>
        </div>
        <div style={s.lunaChip}>
          <div style={s.dot} />
          LUNA · {lunaLog.filter(l => l.result === 'ALLOWED').length} GATES
        </div>
      </div>

      {/* Body */}
      <div style={s.body}>

        {/* ── IDLE ─────────────────────────────────────────────────────────── */}
        {stage === 'idle' && (
          <>
            <div style={s.hint}>
              Describe the job in plain English. Include material, height, footage, gates, and any site conditions.
              <div style={s.hintEx}>
                → 150ft of 6ft black chain link, 2 walk gates, HOA<br />
                → 300ft wood privacy, one drive gate, rocky soil<br />
                → 200ft 4ft galvanized chain link, back lot
              </div>
            </div>
            <label style={s.label}>JOB INTAKE — NATURAL LANGUAGE</label>
            <textarea
              style={s.textarea}
              rows={4}
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder="Describe the fence job..."
            />
            <button style={s.runBtn} onClick={runJob}>
              RUN HARDSAW ENGINE ↗
            </button>
          </>
        )}

        {/* ── THINKING ─────────────────────────────────────────────────────── */}
        {stage === 'thinking' && (
          <div style={s.thinking}>
            <span style={s.thinkingIcon}>⚙</span>
            LUNA GATING<br />MIRE NORMALIZING<br />ESTIMATOR RUNNING...
          </div>
        )}

        {/* ── RESULT ───────────────────────────────────────────────────────── */}
        {stage === 'result' && job && (() => {
          const { spec, geo, result, readiness, vaultChain } = job
          const status = readiness.status

          return (
            <>
              <button style={s.newJobBtn} onClick={reset}>← NEW JOB</button>

              {/* Status bar */}
              <div style={s.statusBar(status)}>
                <div>
                  <div style={s.statusLabel(status)}>{STATUS[status].label}</div>
                  <div style={s.statusSub}>
                    {spec.linear_ft}ft · {spec.family.replace(/_/g,' ')} · {spec.height_ft}ft · {spec.finish}
                  </div>
                </div>
                <div style={s.statusHash}>#{result?.output_hash?.slice(0,8) || '--------'}</div>
              </div>

              {/* Assist chat */}
              <div style={s.chatWrap}>
                <div style={s.chatHead}>
                  <span>ASSIST · LUNA-BOUNDED</span>
                  <span style={{ color: C.dim }}>EXPLAIN ONLY</span>
                </div>
                <div style={s.chatBody}>
                  {chat.length === 0 && (
                    <div style={{ color: C.muted, fontSize: 11 }}>Assist is loading summary...</div>
                  )}
                  {chat.map((m, i) => (
                    <div key={i} style={s.chatMsg(m.role)}>
                      <div style={s.chatRole(m.role)}>{m.role === 'assist' ? 'ASSIST' : 'YOU'}</div>
                      {m.text}
                    </div>
                  ))}
                  {chatLoading && (
                    <div style={s.chatMsg('assist')}>
                      <div style={s.chatRole('assist')}>ASSIST</div>
                      <span style={{ color: C.muted }}>thinking...</span>
                    </div>
                  )}
                  <div ref={chatEndRef} />
                </div>
                <div style={s.chatInputRow}>
                  <input
                    style={s.chatInput}
                    value={chatInput}
                    onChange={e => setChatInput(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter') sendChat() }}
                    placeholder="Ask about this job..."
                  />
                  <button style={s.chatSend} onClick={sendChat}>↗</button>
                </div>
              </div>

              {/* Spec card */}
              <div style={s.card}>
                <div style={s.cardTitle}>CANONICAL SPEC — MIRE OUTPUT</div>
                <div style={s.specGrid}>
                  {[
                    ['FAMILY',    spec.family.replace(/_/g,' ').toUpperCase()],
                    ['HEIGHT',    `${spec.height_ft}ft`],
                    ['LINEAR FT', spec.linear_ft ?? '—'],
                    ['FINISH',    spec.finish.toUpperCase()],
                    ['GATES',     `${spec.gates} (${spec.gate_type})`],
                    ['SECTIONS',  geo?.sections ?? '—'],
                  ].map(([k,v]) => (
                    <div key={k}>
                      <div style={s.specKey}>{k}</div>
                      <div style={s.specVal}>{v}</div>
                    </div>
                  ))}
                </div>
                {spec.site_flags.length > 0 && (
                  <div style={s.flags}>FLAGS: {spec.site_flags.join(' · ')}</div>
                )}
              </div>

              {/* Tabs */}
              <div style={s.tabs}>
                {TABS.map(t => (
                  <button key={t} style={s.tab(tab === t)} onClick={() => setTab(t)}>{t}</button>
                ))}
              </div>

              {/* Tab content */}
              <div style={s.card}>

                {/* BOM */}
                {tab === 'BOM' && result && (
                  <>
                    <div style={s.bomHead}>
                      <span>ITEM</span><span>QTY</span><span>UNIT $</span><span>SUBTOTAL</span>
                    </div>
                    {result.bom.map((item, i) => (
                      <div key={i} style={s.bomRow}>
                        <div>
                          <div>{item.line}</div>
                          <div style={s.bomSku}>{item.sku}</div>
                        </div>
                        <div style={{ color: C.amber }}>{item.qty}</div>
                        <div style={{ color: C.muted }}>${item.price}</div>
                        <div>${(item.qty * item.price).toFixed(0)}</div>
                      </div>
                    ))}
                    <div style={s.totalRow}>
                      <span style={{ color: C.muted, fontSize: 10 }}>MATERIAL</span>
                      <span style={{ color: C.amber, fontWeight: 'bold' }}>${result.totalMaterial.toLocaleString()}</span>
                    </div>
                    <div style={{ ...s.totalRow, paddingTop: 5, borderTop: 'none', fontSize: 11 }}>
                      <span style={{ color: C.muted, fontSize: 10 }}>LABOR EST.</span>
                      <span style={{ color: '#888' }}>${result.laborEstimate.toLocaleString()}</span>
                    </div>
                    <div style={{ ...s.totalRow, borderTop: `1px solid ${C.dim}`, marginTop: 4, fontSize: 14 }}>
                      <span style={{ color: '#999' }}>TOTAL</span>
                      <span style={{ fontWeight: 'bold' }}>${(result.totalMaterial + result.laborEstimate).toLocaleString()}</span>
                    </div>
                    <div style={s.hashLine}>GEO: {geo?.geometry_hash} · OUT: {result.output_hash}</div>
                    <div style={s.hashLine}>RULEPACK: {result.rulepack_version} · VENDOR: {result.vendor_version} ({result.vendor_name})</div>
                  </>
                )}
                {tab === 'BOM' && !result && (
                  <div style={{ color: C.red, fontSize: 12 }}>
                    {readiness.blockers.map((b, i) => <div key={i}>⛔ {b}</div>)}
                  </div>
                )}

                {/* READINESS */}
                {tab === 'READY' && (
                  <>
                    <div style={s.readyStatus(status)}>{STATUS[status].label}</div>
                    {readiness.blockers.length > 0 && (
                      <>
                        <div style={s.specKey}>BLOCKERS</div>
                        <ul style={s.alertList}>
                          {readiness.blockers.map((b, i) => <li key={i} style={s.alertItem('blocker')}>⛔ {b}</li>)}
                        </ul>
                      </>
                    )}
                    {readiness.warnings.length > 0 && (
                      <>
                        <div style={s.specKey}>WARNINGS</div>
                        <ul style={s.alertList}>
                          {readiness.warnings.map((w, i) => <li key={i} style={s.alertItem('warn')}>⚠ {w}</li>)}
                        </ul>
                      </>
                    )}
                    {readiness.blockers.length === 0 && readiness.warnings.length === 0 && (
                      <div style={{ color: C.green, fontSize: 13 }}>All checks passed. Clear to execute.</div>
                    )}
                  </>
                )}

                {/* PACKETS */}
                {tab === 'PACKETS' && (
                  <>
                    <div style={s.packetSection}>
                      <div style={s.packetHead}>CONTRACTOR PACKET</div>
                      <div style={s.packetBody}>
                        Job ID: {result?.output_hash || 'N/A'}<br />
                        {spec.linear_ft}ft · {spec.height_ft}ft {spec.family.replace(/_/g,' ')} · {spec.finish}<br />
                        Gates: {spec.gates} ({spec.gate_type}) · Status: {status.toUpperCase()}<br />
                        Material: ${result?.totalMaterial?.toLocaleString() || 'N/A'} · Labor: ${result?.laborEstimate?.toLocaleString() || 'N/A'}
                      </div>
                    </div>
                    <div style={s.packetSection}>
                      <div style={s.packetHead}>SUPPLIER PACKET (PO)</div>
                      <div style={s.packetBody}>
                        PO: {result?.output_hash || 'N/A'} · Vendor: {result?.vendor_name || 'N/A'}<br />
                        {result?.bom?.map((item, i) => <span key={i}>{item.qty}× {item.sku}<br /></span>)}
                      </div>
                    </div>
                    <div style={s.packetSection}>
                      <div style={s.packetHead}>CREW PACKET</div>
                      <div style={s.packetBody}>
                        {spec.linear_ft}lf · {geo?.sections} sections<br />
                        {geo?.terminal_posts} terminal posts · {geo?.line_posts} line posts<br />
                        Spacing: {geo?.post_spacing_ft}ft O.C. · Gates: {spec.gates}<br />
                        {readiness.warnings.length > 0
                          ? '⚠ ' + readiness.warnings.join(' | ')
                          : 'No site flags.'}
                      </div>
                    </div>
                  </>
                )}

                {/* VAULT */}
                {tab === 'VAULT' && (
                  <>
                    <div style={s.cardTitle}>LIFEVAULT — APPEND-ONLY CHAIN</div>
                    {vaultChain.map((entry, i) => (
                      <div key={i} style={s.vaultRow}>
                        <span style={s.vaultEvent}>{entry.eventType}</span>
                        <span style={s.vaultHash}>{entry.hash}</span>
                        <span style={{ ...s.vaultHash, color: '#1E1E1E' }}>↑{entry.prev}</span>
                      </div>
                    ))}
                  </>
                )}
              </div>

              {/* Luna gate log */}
              {lunaLog.length > 0 && (
                <div style={{ ...s.card, background: '#080808' }}>
                  <div style={s.cardTitle}>LUNA GATE LOG</div>
                  {lunaLog.map((l, i) => (
                    <div key={i} style={s.lunaRow}>
                      <span style={{ color: l.result === 'ALLOWED' ? C.green : C.red, minWidth: 56 }}>{l.result}</span>
                      <span style={{ color: C.muted }}>{l.action}</span>
                    </div>
                  ))}
                </div>
              )}
            </>
          )
        })()}
      </div>
    </div>
  )
}
